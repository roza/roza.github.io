#!/usr/bin/env python3
"""cat d'un fichier en cours de téléchargement : s'arrête quand TOTAL octets ont été émis."""
import sys, os, time
path, total = sys.argv[1], int(sys.argv[2])
out = sys.stdout.buffer; n = 0; idle = 0
with open(path, "rb") as f:
    while n < total:
        b = f.read(1 << 22)
        if b:
            out.write(b); n += len(b); idle = 0
        else:
            idle += 1
            if idle > 1800: sys.exit("timeout: download stalled")
            time.sleep(1)
out.flush()
