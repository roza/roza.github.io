#!/usr/bin/env python3
"""Table nom de déclaration -> (paquet, module) à partir des .ilean (JSON, champ "decls")."""
import json, os, sys
roots = {
  "core": os.path.expanduser("~/.elan/toolchains/leanprover--lean4---v4.33.1/lib/lean"),
}
base = "/Users/roza/rh-check/src/lean/.lake"
for p in sorted(os.listdir(base + "/packages")):
    roots[p] = f"{base}/packages/{p}/.lake/build/lib/lean"
roots["projet"] = f"{base}/build/lib/lean"
out = open(sys.argv[1], "w", encoding="utf-8")
for pkg, r in roots.items():
    n = 0
    for dp, _, fs in os.walk(r):
        for f in fs:
            if not f.endswith(".ilean"): continue
            p = os.path.join(dp, f)
            mod = os.path.relpath(p, r)[:-6].replace("/", ".")
            try: d = json.load(open(p, encoding="utf-8")).get("decls", {})
            except Exception as e: print("ERR", p, e, file=sys.stderr); continue
            for k in d: out.write(f"{k}\t{pkg}\t{mod}\n")
            n += 1
    print(pkg, n, file=sys.stderr)
